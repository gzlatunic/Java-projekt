/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gabrijela
 */
public class DvijeMatrice {
    
    public final double[][] A;
    public final double[][] B;
    public DvijeMatrice(double[][] A, double[][] B){
        this.A = A;
        this.B = B;
    }
    
}
