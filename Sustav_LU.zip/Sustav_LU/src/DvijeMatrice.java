/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gabrijela
 */
public class DvijeMatrice {
    
    public final Matrica A;
    public final Matrica B;
    public DvijeMatrice(Matrica A, Matrica B){
        this.A = A;
        this.B = B;
    }
    
}
